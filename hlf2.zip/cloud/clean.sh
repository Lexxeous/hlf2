rm artefacts/*   2> /dev/null
rm -rf temp      2> /dev/null
rm *.block       2> /dev/null
rm -rf crypto-config        2> /dev/null

echo "Done."