Fabric 2.x
==========
Fabric 2.0 has introduced major enhancements to the chaincode lifecylce mangement
This course's focus is on "Fabric Network Design & Setup" hence it does not go into
the depths of the Fabric Chaincode development. If you are interested in learning
Chaincode development, please take a look at my course "Fabric Chaincode Development
using GoLang". Checkout the website 

http://www.bcmentors.com

