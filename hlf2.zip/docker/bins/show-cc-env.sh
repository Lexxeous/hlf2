#!/bin/bash
#Shows the environment variable values for CC_
env | grep CC_