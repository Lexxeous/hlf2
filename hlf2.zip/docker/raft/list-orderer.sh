#!/bin/bash
#Lists the orderer
docker ps | grep orderer
